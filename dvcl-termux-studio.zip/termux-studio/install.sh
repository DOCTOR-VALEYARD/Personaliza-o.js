#!/data/data/com.termux/files/usr/bin/bash
# Termux Studio — instalador
# Criador: Doctor Valeyard C'rizz Lunático

R='\033[1;31m'; W='\033[1;37m'; G='\033[1;32m'; N='\033[0m'
DIR="$(cd "$(dirname "$0")" && pwd)"

echo -e "${R}▣▣▣▣ TERMUX STUDIO ▣▣▣▣${N}"
echo -e "${W}Doctor Valeyard C'rizz Lunático${N}\n"

if ! command -v node >/dev/null 2>&1; then
  echo -e "${R}➤ Node.js não encontrado. Instalando...${N}"
  if command -v pkg >/dev/null 2>&1; then
    pkg install -y nodejs || { echo -e "${R}✘ Falha ao instalar o Node.js.${N}"; exit 1; }
  else
    echo -e "${R}✘ Instale o Node.js manualmente e rode de novo.${N}"; exit 1
  fi
fi

echo -e "${G}✔ Node.js: $(node --version)${N}"
echo -e "${R}➤ Abrindo o Termux Studio...${N}\n"
sleep 1
exec node "$DIR/termux-studio.js"
