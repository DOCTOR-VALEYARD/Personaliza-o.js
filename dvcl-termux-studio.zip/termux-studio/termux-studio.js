#!/usr/bin/env node
'use strict';
/*
 ╔══════════════════════════════════════════════════════════╗
 ║  TERMUX STUDIO — Personalizador profissional do Termux   ║
 ║  Criador: Doctor Valeyard C'rizz Lunático                ║
 ║  Sem dependências: só precisa do Node.js                 ║
 ╚══════════════════════════════════════════════════════════╝
*/

const fs = require('fs');
const path = require('path');
const os = require('os');
const readline = require('readline');
const crypto = require('crypto');

// ───────────────────────────── Caminhos ─────────────────────────────
const HOME = process.env.HOME || os.homedir();
const DIR = path.join(HOME, '.dvcl_termux');
const CONFIG = path.join(DIR, 'config.json');
const BOOT = path.join(DIR, 'boot.sh');
const INSTALLED = path.join(DIR, 'termux-studio.js');
const RC_BACKUP = path.join(DIR, 'bashrc.backup');
const BASHRC = path.join(HOME, '.bashrc');
const HUSH = path.join(HOME, '.hushlogin');
const MARK_START = "# >>> TERMUX STUDIO (Doctor Valeyard C'rizz Lunático) >>>";
const MARK_END = "# <<< TERMUX STUDIO (Doctor Valeyard C'rizz Lunático) <<<";
const CREDITS = "Doctor Valeyard C'rizz Lunático";

// ───────────────────────────── ANSI / utilitários ─────────────────────────────
const ESC = '\x1b[';
const RESET = ESC + '0m';
const paint = (code, s) => `${ESC}${code}m${s}${RESET}`;
const strip = (s) => String(s).replace(/\x1b\[[0-9;]*[A-Za-z]/g, '');
const vlen = (s) => [...strip(s)].length;
const cols = () => process.stdout.columns || 48;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const out = (s = '') => process.stdout.write(s + '\n');
const clear = () => process.stdout.write('\x1b[3J\x1b[2J\x1b[H');
const RED = '1;31';

const pad2 = (n) => String(n).padStart(2, '0');
const DIAS = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb'];
function agora() {
  const d = new Date();
  return {
    hora: `${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}`,
    data: `${DIAS[d.getDay()]} ${pad2(d.getDate())}/${pad2(d.getMonth() + 1)}/${d.getFullYear()}`,
  };
}
// Relógio SEMPRE vermelho
const clockLine = () => {
  const n = agora();
  return paint('1;31', ` ◉ ${n.hora}`) + paint('31', `  ${n.data}`);
};

function wrapText(s, w) {
  const res = [];
  for (const p of String(s).split('\n')) {
    let line = '';
    for (let word of p.split(/\s+/).filter(Boolean)) {
      while ([...word].length > w) {
        if (line) { res.push(line); line = ''; }
        res.push([...word].slice(0, w).join(''));
        word = [...word].slice(w).join('');
      }
      if (!line) line = word;
      else if ([...line].length + 1 + [...word].length <= w) line += ' ' + word;
      else { res.push(line); line = word; }
    }
    res.push(line);
  }
  return res;
}
const trunc = (s, n) => ([...s].length > n ? [...s].slice(0, Math.max(1, n - 1)).join('') + '…' : s);

function box(lines, { title = '', color = RED, minInner = 0 } = {}) {
  const t = title ? ` ${title} ` : '';
  const inner = Math.max(minInner, vlen(t) + 1, ...lines.map(vlen));
  const c = (s) => paint(color, s);
  const top = c('╔═' + t + '═'.repeat(inner + 1 - vlen(t)) + '╗');
  const mid = lines.map((l) => c('║') + ' ' + l + ' '.repeat(inner - vlen(l)) + ' ' + c('║'));
  const bot = c('╚' + '═'.repeat(inner + 2) + '╝');
  return [top, ...mid, bot];
}

// ───────────────────────────── Cores ─────────────────────────────
const RAINBOW = ['1;31', '38;5;208', '1;33', '1;32', '1;36', '1;34', '1;35'];
const COLORS = [
  { name: 'Vermelho', code: '1;31' },
  { name: 'Vermelho escuro', code: '38;5;124' },
  { name: 'Laranja', code: '38;5;208' },
  { name: 'Amarelo', code: '1;33' },
  { name: 'Dourado', code: '38;5;220' },
  { name: 'Verde', code: '1;32' },
  { name: 'Verde limão', code: '38;5;118' },
  { name: 'Ciano', code: '1;36' },
  { name: 'Azul claro', code: '38;5;39' },
  { name: 'Azul', code: '1;34' },
  { name: 'Roxo', code: '38;5;141' },
  { name: 'Magenta', code: '1;35' },
  { name: 'Rosa', code: '38;5;213' },
  { name: 'Branco', code: '1;37' },
  { name: 'Cinza', code: '38;5;245' },
  { name: 'Arco-íris', code: null, rainbow: true },
];
function paintLines(lines, colorIdx) {
  const col = COLORS[colorIdx] || COLORS[0];
  return lines.map((l, i) => paint(col.rainbow ? RAINBOW[i % RAINBOW.length] : col.code, l));
}
function paintText(text, colorIdx) {
  const col = COLORS[colorIdx] || COLORS[0];
  if (!col.rainbow) return paint(col.code, text);
  return [...text].map((ch, i) => paint(RAINBOW[i % RAINBOW.length], ch)).join('');
}

// ───────────────────────────── Fonte de letras (5x5) ─────────────────────────────
const G = (a, b, c, d, e) => [a, b, c, d, e];
const FONT = {
  A: G('01110', '10001', '11111', '10001', '10001'),
  B: G('11110', '10001', '11110', '10001', '11110'),
  C: G('01111', '10000', '10000', '10000', '01111'),
  D: G('11110', '10001', '10001', '10001', '11110'),
  E: G('11111', '10000', '11110', '10000', '11111'),
  F: G('11111', '10000', '11110', '10000', '10000'),
  G: G('01111', '10000', '10011', '10001', '01111'),
  H: G('10001', '10001', '11111', '10001', '10001'),
  I: G('11111', '00100', '00100', '00100', '11111'),
  J: G('00111', '00010', '00010', '10010', '01100'),
  K: G('10001', '10010', '11100', '10010', '10001'),
  L: G('10000', '10000', '10000', '10000', '11111'),
  M: G('10001', '11011', '10101', '10001', '10001'),
  N: G('10001', '11001', '10101', '10011', '10001'),
  O: G('01110', '10001', '10001', '10001', '01110'),
  P: G('11110', '10001', '11110', '10000', '10000'),
  Q: G('01110', '10001', '10101', '10010', '01101'),
  R: G('11110', '10001', '11110', '10010', '10001'),
  S: G('01111', '10000', '01110', '00001', '11110'),
  T: G('11111', '00100', '00100', '00100', '00100'),
  U: G('10001', '10001', '10001', '10001', '01110'),
  V: G('10001', '10001', '10001', '01010', '00100'),
  W: G('10001', '10001', '10101', '11011', '10001'),
  X: G('10001', '01010', '00100', '01010', '10001'),
  Y: G('10001', '01010', '00100', '00100', '00100'),
  Z: G('11111', '00010', '00100', '01000', '11111'),
  0: G('01110', '10011', '10101', '11001', '01110'),
  1: G('00100', '01100', '00100', '00100', '01110'),
  2: G('01110', '10001', '00110', '01000', '11111'),
  3: G('11110', '00001', '01110', '00001', '11110'),
  4: G('10010', '10010', '11111', '00010', '00010'),
  5: G('11111', '10000', '11110', '00001', '11110'),
  6: G('01110', '10000', '11110', '10001', '01110'),
  7: G('11111', '00001', '00010', '00100', '00100'),
  8: G('01110', '10001', '01110', '10001', '01110'),
  9: G('01110', '10001', '01111', '00001', '01110'),
  ' ': G('000', '000', '000', '000', '000'),
  '-': G('00000', '00000', '11111', '00000', '00000'),
  _: G('00000', '00000', '00000', '00000', '11111'),
  '.': G('000', '000', '000', '000', '010'),
  '!': G('010', '010', '010', '000', '010'),
};

const normalizeName = (s) => String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase();
const nameChars = (s) => [...normalizeName(s)].filter((c) => FONT[c]);

// ───────────────────────────── 16 estilos de arte ─────────────────────────────
const dbl = (c, w) => (w === 2 ? c + c : c);
const sym = (c, w) => (w === 2 ? c + ' ' : c);
const blank = (w) => ' '.repeat(w);

function shadowStr(F, x, y, w) {
  const L = F(x - 1, y), U = F(x, y - 1), UL = F(x - 1, y - 1);
  let k = null;
  if (L && UL) k = 'v';
  else if (L) k = 'tr';
  else if (U && UL) k = 'h';
  else if (U) k = 'bl';
  else if (UL) k = 'br';
  if (!k) return null;
  const two = { v: '║ ', tr: '╗ ', h: '══', bl: '╚═', br: '╝ ' };
  const one = { v: '║', tr: '╗', h: '═', bl: '╚', br: '╝' };
  return w === 2 ? two[k] : one[k];
}

const STYLES = [
  { name: 'Bloco sólido', cell: (f, F, x, y, w) => (f ? dbl('█', w) : blank(w)) },
  { name: 'Bloco com fundo ░', cell: (f, F, x, y, w) => (f ? dbl('█', w) : dbl('░', w)) },
  { name: 'Sombra ANSI (╗ ═)', cell: (f, F, x, y, w) => (f ? dbl('█', w) : shadowStr(F, x, y, w) || blank(w)) },
  { name: 'Sombra ANSI com fundo ░', cell: (f, F, x, y, w) => (f ? dbl('█', w) : shadowStr(F, x, y, w) || dbl('░', w)) },
  { name: '3D extrusão', cell: (f, F, x, y, w) => (f ? dbl('█', w) : F(x - 1, y - 1) ? dbl('▒', w) : blank(w)) },
  { name: 'Degradê ▓░', cell: (f, F, x, y, w) => (f ? dbl('▓', w) : F(x - 1, y) || F(x - 1, y - 1) ? dbl('░', w) : blank(w)) },
  { name: 'Pontos ●', cell: (f, F, x, y, w) => (f ? sym('●', w) : blank(w)) },
  { name: 'Estrelas ★', cell: (f, F, x, y, w) => (f ? sym('★', w) : blank(w)) },
  { name: 'Diamantes ◆', cell: (f, F, x, y, w) => (f ? sym('◆', w) : blank(w)) },
  { name: 'Caixas ▣', cell: (f, F, x, y, w) => (f ? sym('▣', w) : blank(w)) },
  { name: 'Corações ♥', cell: (f, F, x, y, w) => (f ? sym('♥', w) : blank(w)) },
  { name: 'Hash ##', cell: (f, F, x, y, w) => (f ? dbl('#', w) : blank(w)) },
  { name: 'Asteriscos **', cell: (f, F, x, y, w) => (f ? dbl('*', w) : blank(w)) },
  { name: 'Barras ||', cell: (f, F, x, y, w) => (f ? dbl('|', w) : blank(w)) },
  { name: 'Traços //', cell: (f, F, x, y, w) => (f ? dbl('/', w) : blank(w)) },
  { name: 'Ondas ~~', cell: (f, F, x, y, w) => (f ? dbl('~', w) : blank(w)) },
];

// Gera as linhas da arte. Quebra o nome em várias linhas se a tela for estreita.
function renderArt(text, styleIdx, maxCols = cols(), forceW = 0) {
  const chars = nameChars(text);
  if (!chars.length) return [];
  const gw = (c) => FONT[c][0].length;
  const cellsOf = (arr) => arr.reduce((s, c) => s + gw(c), 0) + (arr.length - 1) + 1;
  const avail = Math.max(8, maxCols - 1);
  let w = forceW || (cellsOf(chars) * 2 > avail ? 1 : 2);
  const chunks = [];
  let cur = [];
  for (const c of chars) {
    const t = [...cur, c];
    if (cur.length && cellsOf(t) * w > avail) { chunks.push(cur); cur = [c]; } else cur = t;
  }
  if (cur.length) chunks.push(cur);

  const lines = [];
  for (const ch of chunks) {
    const rows = ['', '', '', '', ''];
    ch.forEach((c, i) => { for (let r = 0; r < 5; r++) rows[r] += FONT[c][r] + (i < ch.length - 1 ? '0' : ''); });
    for (let r = 0; r < 5; r++) rows[r] += '0';
    rows.push('0'.repeat(rows[0].length));
    const H = rows.length, W = rows[0].length;
    const F = (x, y) => x >= 0 && y >= 0 && x < W && y < H && rows[y][x] === '1';
    for (let y = 0; y < H; y++) {
      let line = '';
      for (let x = 0; x < W; x++) line += STYLES[styleIdx].cell(F(x, y), F, x, y, w);
      lines.push(line.replace(/\s+$/, ''));
    }
  }
  while (lines.length && !lines[lines.length - 1]) lines.pop();
  return lines;
}

// ───────────────────────────── Configuração ─────────────────────────────
const DEFAULTS = {
  configured: false,
  name: 'TERMUX',
  style: 2,
  artColor: 0,
  label: 'TERMUX',
  promptColor: 0,
  password: null, // { salt, hash }
  welcome: 'Bem-vindo, {nome}! Hoje é {data} e são {hora}.',
  hushCreated: false,
};
function loadConfig() {
  try {
    return { ...DEFAULTS, ...JSON.parse(fs.readFileSync(CONFIG, 'utf8')) };
  } catch {
    return { ...DEFAULTS };
  }
}
function hashPass(pass, salt = crypto.randomBytes(16).toString('hex')) {
  return { salt, hash: crypto.scryptSync(pass, salt, 32).toString('hex') };
}
function checkPass(pass, rec) {
  if (!rec) return true;
  const a = Buffer.from(crypto.scryptSync(pass, rec.salt, 32).toString('hex'));
  const b = Buffer.from(rec.hash);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
const cleanLabel = (s) => [...String(s).replace(/[\\$`'"\x00-\x1f\x7f]/g, '')].slice(0, 24).join('').trim();
const cleanName = (s) => [...String(s).replace(/[\x00-\x1f\x7f]/g, '')].slice(0, 20).join('').trim();

// ───────────────────────────── Entrada do usuário ─────────────────────────────
function ask(q) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    let done = false;
    rl.on('close', () => { if (!done) { done = true; resolve(''); } });
    rl.question(q, (a) => { done = true; rl.close(); resolve(a.trim()); });
  });
}
function askHidden(q) {
  const stdin = process.stdin;
  if (!stdin.isTTY) return ask(q);
  return new Promise((resolve) => {
    process.stdout.write(q);
    let buf = '';
    readline.emitKeypressEvents(stdin);
    stdin.setRawMode(true);
    stdin.resume();
    const finish = (val, code) => {
      stdin.removeListener('keypress', onKey);
      stdin.setRawMode(false);
      stdin.pause();
      process.stdout.write('\n');
      if (code !== undefined) process.exit(code);
      resolve(val);
    };
    const onKey = (str, key = {}) => {
      if (key.name === 'return' || key.name === 'enter') return finish(buf);
      if (key.ctrl && key.name === 'c') return finish('', 130);
      if (key.name === 'backspace') {
        if (buf.length) { buf = [...buf].slice(0, -1).join(''); process.stdout.write('\b \b'); }
        return;
      }
      if (str && !key.ctrl && !key.meta) { buf += str; process.stdout.write('•'.repeat([...str].length)); }
    };
    stdin.on('keypress', onKey);
  });
}
const prompt = (txt) => paint(RED, ' ➤ ') + paint('1;37', txt);
async function pausa(txt = 'Pressione ENTER para continuar') {
  await ask(paint('31', `\n ${txt}... `));
}

// ───────────────────────────── Barra de carregamento ▣▣▣▣ ─────────────────────────────
async function progress(title, steps, total = 1500) {
  const barW = Math.max(10, Math.min(22, cols() - 18));
  const frames = process.stdout.isTTY ? 40 : 1;
  const render = (pct, msg) => {
    const filled = Math.round((pct / 100) * barW);
    const bar = paint('1;31', '▣'.repeat(filled)) + paint('90', '▢'.repeat(barW - filled));
    const line = `${bar} ${paint('1;37', String(pct).padStart(3) + '%')}`;
    return [...box([line], { title, minInner: barW + 5 }), paint('31', ' ➤ ') + paint('1;33', msg)];
  };
  let first = true;
  for (let f = 0; f <= frames; f++) {
    const pct = Math.round((f / frames) * 100);
    const idx = Math.min(steps.length - 1, Math.floor((f / (frames + 1)) * steps.length));
    const lines = render(pct, steps[idx] + (pct < 100 ? ' ...' : ''));
    if (!first && process.stdout.isTTY) process.stdout.write(`\x1b[${lines.length}A`);
    for (const l of lines) process.stdout.write('\x1b[2K\r' + l + '\n');
    first = false;
    if (process.stdout.isTTY) await sleep(total / frames);
  }
  process.stdout.write('\x1b[2K\r' + paint('1;32', ' ✔ ') + paint('1;37', 'Concluído!') + '\n');
  if (process.stdout.isTTY) await sleep(350);
}

// ───────────────────────────── Telas ─────────────────────────────
function header(sub = '') {
  clear();
  out(clockLine());
  out();
  for (const l of paintLines(renderArt('TERMUX', 2, cols(), 1), 0)) out(' ' + l);
  out(paint('31', ` ${'═'.repeat(Math.max(10, Math.min(cols() - 2, 46)))}`));
  out(paint('1;31', ' ✦ STUDIO ✦ ') + paint('90', `por ${CREDITS}`));
  if (sub) { out(); out(paint('1;37', ` ${sub}`)); }
  out();
}

function fmtWelcome(c) {
  const n = agora();
  return String(c.welcome).replace(/\{nome\}/gi, c.name).replace(/\{hora\}/gi, n.hora).replace(/\{data\}/gi, n.data);
}

function bootScreen(c, preview = false) {
  clear();
  out(clockLine());
  out();
  for (const l of paintLines(renderArt(c.name, c.style, cols()), c.artColor)) out(' ' + l);
  out();
  if (c.welcome) {
    const inner = Math.max(12, Math.min(cols() - 6, 46));
    const lines = wrapText(fmtWelcome(c), inner).map((l) => paint('1;37', l));
    for (const l of box(lines, { title: 'BOAS-VINDAS' })) out(' ' + l);
  }
  out(paint('31', ` ✦ Criado por ${CREDITS}`));
  out();
  if (preview) {
    out(' ' + paintText(`▭❦❲${c.label}❳❦▭`, c.promptColor) + paint('31', ' ls'));
    out(paint('31', ' Downloads  Documents  storage  projetos'));
    out(' ' + paintText(`▭❦❲${c.label}❳❦▭`, c.promptColor) + paint('31', ' _'));
    out();
  }
}

async function chooseStyle(c) {
  let page = 0;
  const per = 4, pages = Math.ceil(STYLES.length / per);
  for (;;) {
    header(`ESTILO DA ARTE — página ${page + 1}/${pages}`);
    for (let i = page * per; i < Math.min(STYLES.length, (page + 1) * per); i++) {
      out(paint('1;33', ` [${i + 1}] `) + paint('1;37', STYLES[i].name) + (i === c.style ? paint('1;32', '  ◀ atual') : ''));
      for (const l of paintLines(renderArt(c.name, i), c.artColor)) out('   ' + l);
      out();
    }
    out(paint('31', ` Digite o número (1-${STYLES.length}) · N = próxima · P = anterior · ENTER = voltar`));
    const r = (await ask(prompt('Estilo: '))).toLowerCase();
    if (r === '') return false;
    if (r === 'n') page = (page + 1) % pages;
    else if (r === 'p') page = (page - 1 + pages) % pages;
    else {
      const n = parseInt(r, 10);
      if (n >= 1 && n <= STYLES.length) {
        await progress('APLICANDO ESTILO', ['Carregando estilo ' + STYLES[n - 1].name, 'Convertendo letras em arte', 'Montando o banner']);
        c.style = n - 1;
        return true;
      }
    }
  }
}

async function chooseColor(c, alvo) {
  const isArt = alvo === 'art';
  const key = isArt ? 'artColor' : 'promptColor';
  for (;;) {
    header(isArt ? 'COR DA ARTE' : 'COR DO SÍMBOLO DO PROMPT');
    COLORS.forEach((col, i) => {
      const swatch = col.rainbow ? paintText('████', i) : paint(col.code, '████');
      out(paint('1;33', ` [${String(i + 1).padStart(2)}] `) + swatch + ' ' + paint('1;37', col.name) + (i === c[key] ? paint('1;32', '  ◀ atual') : ''));
    });
    out();
    out(paint('31', ' ENTER = voltar'));
    const r = await ask(prompt('Cor: '));
    if (r === '') return false;
    const n = parseInt(r, 10);
    if (n >= 1 && n <= COLORS.length) {
      await progress('APLICANDO COR', ['Carregando paleta', 'Pintando ' + (isArt ? 'a arte' : 'o símbolo') + ' de ' + COLORS[n - 1].name]);
      c[key] = n - 1;
      return true;
    }
  }
}

async function setName(c) {
  header('NOME DA ARTE');
  out(paint('31', ' Letras (A-Z), números, espaço, - _ . !  (máx. 20)'));
  out(paint('31', ' ENTER vazio = voltar'));
  out();
  const v = cleanName(await ask(prompt('Digite o nome: ')));
  if (!v) return false;
  if (!nameChars(v).length) {
    out(paint('1;31', '\n ✘ Nome inválido. Use letras ou números.'));
    await pausa();
    return false;
  }
  await progress('APLICANDO NOME', ['Lendo o nome digitado', 'Convertendo letras em arte', 'Preparando os 16 estilos']);
  c.name = v;
  return true;
}

async function setLabel(c) {
  header('SÍMBOLO DO PROMPT (substitui o $)');
  out(paint('31', ' Vai aparecer assim:  ') + paintText('▭❦❲SEU TEXTO❳❦▭', c.promptColor));
  out(paint('31', ' Máx. 24 caracteres. Os símbolos \\ $ ` \' " são removidos.'));
  out(paint('31', ' ENTER vazio = voltar'));
  out();
  const v = cleanLabel(await ask(prompt('Texto do prompt: ')));
  if (!v) return false;
  await progress('APLICANDO PROMPT', ['Montando ▭❦❲' + v + '❳❦▭', 'Gerando o PS1']);
  c.label = v;
  return true;
}

async function passwordMenu(c) {
  header('SENHA DE ENTRADA');
  out(paint('1;37', ` Situação: `) + (c.password ? paint('1;32', 'ATIVADA') : paint('1;31', 'DESATIVADA')));
  out();
  out(paint('1;33', ' [1] ') + 'Definir / alterar senha');
  out(paint('1;33', ' [2] ') + 'Remover senha');
  out(paint('1;33', ' [0] ') + 'Voltar');
  out();
  const r = await ask(prompt('Escolha: '));
  if (r === '1') {
    const p1 = await askHidden(prompt('Nova senha (mín. 4): '));
    if (p1.length < 4) { out(paint('1;31', '\n ✘ Senha muito curta.')); await pausa(); return false; }
    const p2 = await askHidden(prompt('Repita a senha: '));
    if (p1 !== p2) { out(paint('1;31', '\n ✘ As senhas não conferem.')); await pausa(); return false; }
    await progress('SENHA', ['Gerando sal aleatório', 'Criptografando a senha (scrypt)', 'Ativando proteção']);
    c.password = hashPass(p1);
    return true;
  }
  if (r === '2') {
    await progress('SENHA', ['Removendo proteção']);
    c.password = null;
    return true;
  }
  return false;
}

async function welcomeMenu(c) {
  header('MENSAGEM DE BOAS-VINDAS');
  out(paint('31', ' Variáveis: {nome} {hora} {data}'));
  out(paint('1;37', ' Atual: ') + (c.welcome ? paint('1;33', c.welcome) : paint('1;31', 'desativada')));
  out();
  out(paint('31', ' Digite a nova mensagem · - (traço) = desativar · ENTER = voltar'));
  const v = await ask(prompt('Mensagem: '));
  if (!v) return false;
  await progress('BOAS-VINDAS', [v === '-' ? 'Desativando mensagem' : 'Gravando mensagem']);
  c.welcome = v === '-' ? '' : v.slice(0, 200);
  return true;
}

// ───────────────────────────── Geração dos arquivos ─────────────────────────────
function buildPS1(c) {
  const label = `▭❦❲${c.label}❳❦▭`;
  const col = COLORS[c.promptColor] || COLORS[0];
  const cp = (code, s) => `\\[\\e[${code}m\\]${s}`;
  const body = col.rainbow
    ? [...label].map((ch, i) => cp(RAINBOW[i % RAINBOW.length], ch)).join('')
    : cp(col.code, label);
  return `${body}\\[\\e[0m\\]\\[\\e[31m\\] `;
}

function buildBootSh(c) {
  const lsColors = 'rs=0:di=31:ln=31:mh=31:pi=31:so=31:do=31:bd=31:cd=31:or=31:mi=31:su=31:sg=31:ca=31:tw=31:ow=31:st=31:ex=31:fi=31:no=31';
  return `# Gerado pelo Termux Studio — ${CREDITS}
# Não edite à mão. Para mudar: digite  studio
case $- in *i*) ;; *) return 0 2>/dev/null || exit 0 ;; esac

if command -v node >/dev/null 2>&1 && [ -f "$HOME/.dvcl_termux/termux-studio.js" ]; then
  node "$HOME/.dvcl_termux/termux-studio.js" --boot
  _studio_rc=$?
  if [ "$_studio_rc" -eq 10 ]; then exit 1; fi
  unset _studio_rc
fi

export LS_COLORS='${lsColors}'
alias studio='node "$HOME/.dvcl_termux/termux-studio.js"'
PS1='${buildPS1(c)}'
PS0='\\e[31m'
printf '\\033[31m'
`;
}

function removeBlock(rc) {
  const a = rc.indexOf(MARK_START);
  const b = rc.indexOf(MARK_END);
  if (a === -1 || b === -1 || b < a) return rc;
  return (rc.slice(0, a) + rc.slice(b + MARK_END.length)).replace(/\n{3,}/g, '\n\n');
}

function applyToSystem(c) {
  fs.mkdirSync(DIR, { recursive: true, mode: 0o700 });
  if (!c.configured && !fs.existsSync(HUSH)) c.hushCreated = true;
  c.configured = true;
  fs.writeFileSync(CONFIG, JSON.stringify(c, null, 2), { mode: 0o600 });

  if (path.resolve(__filename) !== path.resolve(INSTALLED)) fs.copyFileSync(__filename, INSTALLED);
  fs.chmodSync(INSTALLED, 0o755);

  fs.writeFileSync(BOOT, buildBootSh(c), { mode: 0o644 });

  let rc = '';
  try { rc = fs.readFileSync(BASHRC, 'utf8'); } catch {}
  if (!fs.existsSync(RC_BACKUP)) fs.writeFileSync(RC_BACKUP, rc);
  rc = removeBlock(rc).replace(/\s*$/, '\n');
  rc += `\n${MARK_START}\n[ -f "$HOME/.dvcl_termux/boot.sh" ] && . "$HOME/.dvcl_termux/boot.sh"\n${MARK_END}\n`;
  fs.writeFileSync(BASHRC, rc);

  if (!fs.existsSync(HUSH)) fs.writeFileSync(HUSH, '');
}

async function saveAll(c) {
  await progress('SALVANDO', [
    'Gravando configurações',
    'Instalando o Termux Studio',
    'Gerando script de inicialização',
    'Aplicando ao .bashrc',
    'Ocultando mensagem padrão do Termux',
    'Finalizando',
  ], 2400);
  applyToSystem(c);
}

async function restore() {
  header('RESTAURAR TERMUX ORIGINAL');
  out(paint('1;31', ' Isso remove toda a personalização (nome, prompt, senha).'));
  const r = await ask(prompt('Digite SIM para confirmar: '));
  if (r !== 'SIM') return false;
  const c = loadConfig();
  await progress('RESTAURANDO', ['Removendo bloco do .bashrc', 'Apagando arquivos do Studio', 'Devolvendo a tela padrão'], 1800);
  try { fs.writeFileSync(BASHRC, removeBlock(fs.readFileSync(BASHRC, 'utf8')).replace(/\s*$/, '\n')); } catch {}
  if (c.hushCreated) { try { fs.unlinkSync(HUSH); } catch {} }
  try { fs.rmSync(DIR, { recursive: true, force: true }); } catch {}
  out(paint('1;32', '\n ✔ Tudo restaurado. Feche e abra o Termux.'));
  return true;
}

// ───────────────────────────── Boot (roda ao abrir o Termux) ─────────────────────────────
async function boot() {
  const c = loadConfig();
  if (!c.configured) return;
  if (c.password) {
    if (!process.stdin.isTTY) process.exit(10); // sem terminal real: nega por segurança
    let ok = false;
    for (let t = 1; t <= 3 && !ok; t++) {
      clear();
      out(clockLine());
      out();
      for (const l of box([paint('1;37', 'Digite a senha para entrar')], { title: 'ACESSO RESTRITO' })) out(' ' + l);
      out();
      const p = await askHidden(paint('1;31', ' [SENHA] ➤ '));
      ok = checkPass(p, c.password);
      if (!ok) {
        out(paint('1;31', `\n ✘ Senha incorreta (${t}/3)`));
        await sleep(900);
      }
    }
    if (!ok) {
      clear();
      out(paint('1;31', '\n ✘ Acesso negado. Encerrando...'));
      await sleep(900);
      process.exit(10);
    }
  }
  bootScreen(c);
}

// ───────────────────────────── Menu principal ─────────────────────────────
async function menu(c) {
  let dirty = false;
  const mark = (changed) => { if (changed) dirty = true; };
  for (;;) {
    header(dirty ? 'MENU PRINCIPAL  ' + paint('1;33', '(alterações não salvas)') : 'MENU PRINCIPAL');
    const inner = Math.min(cols() - 4, 46);
    const rowsDef = [
      ['1', 'Nome da arte', paint('1;37', trunc(c.name, 18))],
      ['2', 'Estilo da arte', paint('1;37', trunc(`${c.style + 1}. ${STYLES[c.style].name}`, 22))],
      ['3', 'Cor da arte', paintText(COLORS[c.artColor].name, c.artColor)],
      ['4', 'Texto do prompt', paintText(trunc(c.label, 16), c.promptColor)],
      ['5', 'Cor do prompt', paintText(COLORS[c.promptColor].name, c.promptColor)],
      ['6', 'Senha de entrada', c.password ? paint('1;32', 'ativada') : paint('1;31', 'desativada')],
      ['7', 'Boas-vindas', c.welcome ? paint('1;32', 'ativada') : paint('1;31', 'desativada')],
      ['8', 'Visualizar', ''],
      ['9', 'Salvar e sair', ''],
      ['0', 'Sair sem salvar', ''],
      ['R', 'Restaurar Termux original', ''],
    ];
    const lines = rowsDef.map(([k, l, v]) => paint('1;33', `[${k}] `) + paint('1;37', l) + (v ? paint('31', '  ▸ ') + v : ''));
    for (const l of box(lines, { title: 'PAINEL', minInner: Math.min(inner, 38) })) out(' ' + l);
    out();
    const r = (await ask(prompt('Escolha: '))).toLowerCase();
    if (r === '1') { if (await setName(c)) { mark(true); if (await chooseStyle(c)) mark(true); } }
    else if (r === '2') mark(await chooseStyle(c));
    else if (r === '3') mark(await chooseColor(c, 'art'));
    else if (r === '4') mark(await setLabel(c));
    else if (r === '5') mark(await chooseColor(c, 'prompt'));
    else if (r === '6') mark(await passwordMenu(c));
    else if (r === '7') mark(await welcomeMenu(c));
    else if (r === '8') {
      bootScreen(c, true);
      await pausa('Pressione ENTER para voltar ao painel');
    } else if (r === '9') {
      await saveAll(c);
      header();
      for (const l of box([
        paint('1;32', '✔ Tudo salvo com sucesso!'),
        paint('1;37', 'Feche o Termux e abra de novo.'),
        paint('1;37', 'Sua personalização ficará aqui.'),
        paint('31', 'Para editar depois, digite: studio'),
      ], { title: 'PRONTO' })) out(' ' + l);
      out();
      out(paint('31', ` Criado por ${CREDITS}`));
      out();
      return;
    } else if (r === '0') {
      if (dirty) {
        const s = (await ask(prompt('Há alterações não salvas. Sair mesmo? (s/N): '))).toLowerCase();
        if (s !== 's') continue;
      }
      clear();
      out(paint('31', ` Saiu sem salvar. — ${CREDITS}`));
      return;
    } else if (r === 'r') {
      if (await restore()) return;
    }
  }
}

async function wizard(c) {
  if (await setName(c)) {
    await chooseStyle(c);
    await chooseColor(c, 'art');
    await setLabel(c);
    await chooseColor(c, 'prompt');
  }
}

function ajuda() {
  out(`Termux Studio — ${CREDITS}

Uso:
  node termux-studio.js            abre o painel de personalização
  node termux-studio.js --boot     (interno) exibe a tela inicial
  node termux-studio.js --ajuda    mostra esta ajuda
Depois de salvar, digite  studio  para reabrir o painel.`);
}

async function main() {
  const args = process.argv.slice(2);
  if (args.includes('--ajuda') || args.includes('--help') || args.includes('-h')) return ajuda();
  if (args.includes('--boot')) return boot();
  const c = loadConfig();
  if (!c.configured) await wizard(c);
  await menu(c);
}

if (require.main === module) {
  main().then(() => process.exit(process.exitCode || 0)).catch((e) => {
    process.stdout.write(RESET);
    console.error('Erro:', e && e.message ? e.message : e);
    process.exit(1);
  });
}

module.exports = { renderArt, STYLES, COLORS, buildPS1, buildBootSh, removeBlock, hashPass, checkPass, cleanLabel, FONT };
