# TERMUX PERSONALIZER

Personalizador profissional da tela inicial do Termux.

**Criador:** Doctor valeyard C'rizz Lunático

## Recursos

- 16 estilos de arte usando FIGlet.
- Nome personalizado.
- Cor do banner.
- Cor do prompt.
- Prompt no formato `▭❦❲NOME❳❦▭`.
- Relógio no prompt, sempre em vermelho.
- Mensagem de boas-vindas.
- Senha opcional para entrar no personalizador.
- Pré-visualização.
- Barra de carregamento com `▣`.
- Salvamento permanente.
- Integração automática com `~/.bashrc`.
- Não procura outras pastas do projeto: a configuração fica na HOME do Termux.
- Reaplica o prompt automaticamente quando um novo Bash é iniciado.

## Instalação no Termux

```bash
pkg update -y && pkg install nodejs git -y
git clone SEU_REPOSITORIO_AQUI
cd termux-personalizer
npm install
node index.js
```

Ou:

```bash
npm start
```

## Como funciona

A configuração fica em:

```text
~/.termux-personalizer.json
```

E o prompt persistente fica em:

```text
~/.bashrc
```

O programa cria uma área delimitada no `.bashrc`:

```text
# >>> TERMUX PERSONALIZER START >>>
...
# <<< TERMUX PERSONALIZER END <<<
```

Assim, ao executar o personalizador novamente, ele atualiza somente a área criada por ele.

## Depois de salvar

Feche e abra o Termux. O Bash carregará o `.bashrc` e mostrará o prompt personalizado.

Se o Termux for desinstalado, os dados locais também serão perdidos. Se apenas o aplicativo for fechado, a configuração permanece.

## Observação sobre a cor de todos os comandos

O programa controla as mensagens e o prompt que ele próprio cria. A saída de programas externos executados depois (`ls`, `npm`, `node`, etc.) é controlada pelo próprio programa e pode ter cores próprias; não é seguro forçar toda saída de qualquer programa para vermelho.

## Licença

Você pode adaptar este projeto para seu uso e publicar sua própria versão. Mantenha os créditos do criador conforme os termos definidos pelo autor do repositório.
