#!/usr/bin/env node
'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const readline = require('readline');
const figlet = require('figlet');

const HOME = os.homedir();
const CONFIG = path.join(HOME, '.termux-personalizer.json');
const BASHRC = path.join(HOME, '.bashrc');

const C = {
  reset: '\x1b[0m',
  red: '\x1b[31m',
  brightRed: '\x1b[91m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  cyan: '\x1b[36m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  white: '\x1b[37m',
  gray: '\x1b[90m',
  bold: '\x1b[1m'
};

const COLORS = [
  ['Vermelho', 'red'],
  ['Vermelho claro', 'brightRed'],
  ['Verde', 'green'],
  ['Amarelo', 'yellow'],
  ['Ciano', 'cyan'],
  ['Azul', 'blue'],
  ['Magenta', 'magenta'],
  ['Branco', 'white']
];

const STYLES = [
  ['1', 'Standard'],
  ['2', 'Big'],
  ['3', 'Block'],
  ['4', 'Banner'],
  ['5', 'Doom'],
  ['6', 'Slant'],
  ['7', 'Shadow'],
  ['8', 'Small'],
  ['9', '3-D'],
  ['10', '3x5'],
  ['11', '5x7'],
  ['12', 'Bubble'],
  ['13', 'Digital'],
  ['14', 'Lean'],
  ['15', 'Script'],
  ['16', 'Serifcap']
];

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function ask(q) {
  return new Promise(resolve => rl.question(q, a => resolve(a.trim())));
}

function clear() {
  process.stdout.write('\x1b[2J\x1b[H');
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

function color(name, text) {
  return (C[name] || C.red) + text + C.reset;
}

function red(text) {
  return C.red + text + C.reset;
}

function now() {
  return new Date().toLocaleTimeString('pt-BR', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });
}

function defaultConfig() {
  return {
    name: 'TERMUX',
    font: 'Standard',
    color: 'red',
    promptColor: 'red',
    welcome: 'Bem-vindo ao seu Termux personalizado!',
    passwordEnabled: false,
    password: '',
    showBanner: true,
    showClock: true
  };
}

function loadConfig() {
  try {
    return {...defaultConfig(), ...JSON.parse(fs.readFileSync(CONFIG, 'utf8'))};
  } catch {
    return defaultConfig();
  }
}

function saveConfig(cfg) {
  fs.writeFileSync(CONFIG, JSON.stringify(cfg, null, 2), {mode: 0o600});
}

function fig(text, font) {
  try {
    return figlet.textSync(text || 'TERMUX', {font});
  } catch {
    return figlet.textSync(text || 'TERMUX', {font: 'Standard'});
  }
}

function banner(cfg) {
  const art = fig(cfg.name, cfg.font);
  const lines = art.split('\n').map(x => color(cfg.color, x)).join('\n');
  console.log(lines);
}

function header(cfg, title = 'TERMUX PERSONALIZER') {
  clear();
  console.log(red(`╔══════════════════════════════════════════════════════════════╗`));
  console.log(red(`║  ${title.padEnd(58)}║`));
  console.log(red(`║  ${'Doctor valeyard C\\'rizz Lunático'.padEnd(58)}║`));
  console.log(red(`╚══════════════════════════════════════════════════════════════╝`));
  console.log(red(`  🕒 ${now()}`));
  console.log();
}

async function loading(label, steps = [
  'Validando configuração',
  'Preparando arquivos',
  'Aplicando personalização',
  'Salvando preferências'
]) {
  const total = 16;
  for (let i = 0; i < steps.length; i++) {
    for (let p = 0; p <= total; p++) {
      const bar = '▣'.repeat(p) + '·'.repeat(total - p);
      process.stdout.write(`\r${red(`  [${bar}] ${Math.round(p/total*100)}%  ${steps[i]}`)}`);
      await sleep(20);
    }
    process.stdout.write('\n');
  }
  console.log();
}

function makePrompt(cfg) {
  // O horário é sempre vermelho. O nome/área selecionada usa a cor escolhida.
  // PS1 do Bash: \[\e...\] marca códigos invisíveis para o readline.
  const colorCodes = {
    red: '31', brightRed: '91', green: '32', yellow: '33',
    cyan: '36', blue: '34', magenta: '35', white: '37'
  };
  const n = colorCodes[cfg.promptColor] || '31';
  const label = cfg.name.replace(/[^a-zA-Z0-9_ -]/g, '').slice(0, 28) || 'TERMUX';

  return [
    '# >>> TERMUX PERSONALIZER START >>>',
    `export TERMUX_PERSONALIZER_NAME=${JSON.stringify(label)}`,
    `export TERMUX_PERSONALIZER_WELCOME=${JSON.stringify(cfg.welcome || '')}`,
    `export PS1='\\[\\e[31m\\][$(date +%H:%M:%S)] \\[\\e[${n}m\\]▭❦❲${label}❳❦▭ \\[\\e[31m\\]\\$ \\[\\e[0m\\]'`,
    'termux_personalizer_start() {',
    '  if [ -n "$TERMUX_PERSONALIZER_WELCOME" ]; then',
    '    printf "\\033[31m%s\\033[0m\\n" "$TERMUX_PERSONALIZER_WELCOME"',
    '  fi',
    '  return 0',
    '}',
    'termux_personalizer_start',
    '# <<< TERMUX PERSONALIZER END <<<'
  ].join('\n');
}

function applyBashrc(cfg) {
  let old = '';
  try { old = fs.readFileSync(BASHRC, 'utf8'); } catch {}
  const start = '# >>> TERMUX PERSONALIZER START >>>';
  const end = '# <<< TERMUX PERSONALIZER END <<<';
  const block = makePrompt(cfg);
  const re = new RegExp(`${escapeRegex(start)}[\\s\\S]*?${escapeRegex(end)}\\n?`, 'm');

  let next = old;
  if (re.test(next)) next = next.replace(re, block + '\n');
  else next = next.replace(/\s*$/, '') + '\n\n' + block + '\n';

  fs.writeFileSync(BASHRC, next, {mode: 0o600});
}

function escapeRegex(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

async function chooseStyle(cfg) {
  header(cfg, 'ESCOLHA O ESTILO DE ARTE');
  console.log(red('  16 estilos disponíveis:\n'));
  STYLES.forEach(([n, f]) => console.log(red(`  ${n.padStart(2)}. ${f}`)));
  console.log();

  let n = await ask(red('  Escolha o estilo [1-16]: '));
  if (!STYLES.some(x => x[0] === n)) n = '1';
  cfg.font = STYLES.find(x => x[0] === n)[1];

  header(cfg, 'PRÉ-VISUALIZAÇÃO');
  console.log(color(cfg.color, fig(cfg.name || 'TERMUX', cfg.font)));
  await ask(red('\n  ENTER para continuar...'));
}

async function chooseColor(cfg, prompt = false) {
  header(cfg, prompt ? 'COR DO PROMPT' : 'COR DO BANNER');
  COLORS.forEach(([label, key], i) => {
    console.log(red(`  ${i + 1}. `) + color(key, label));
  });
  console.log();

  let n = Number(await ask(red('  Escolha a cor: ')));
  if (!Number.isInteger(n) || n < 1 || n > COLORS.length) n = 1;
  const key = COLORS[n - 1][1];
  if (prompt) cfg.promptColor = key;
  else cfg.color = key;
}

async function setName(cfg) {
  header(cfg, 'NOME DO TERMUX');
  console.log(red('  Digite o nome que aparecerá em arte na tela inicial.\n'));
  const name = await ask(red('  Nome: '));
  if (!name) return;
  cfg.name = name.slice(0, 24);

  header(cfg, 'APLICANDO NOME');
  await loading('Aplicando');
  console.log(color(cfg.color, fig(cfg.name, cfg.font)));
  await ask(red('\n  ENTER para continuar...'));
}

async function setWelcome(cfg) {
  header(cfg, 'MENSAGEM DE BOAS-VINDAS');
  console.log(red('  A mensagem será exibida quando um novo shell iniciar.\n'));
  const value = await ask(red(`  Mensagem [${cfg.welcome}]: `));
  if (value) cfg.welcome = value;
}

async function setPassword(cfg) {
  header(cfg, 'SENHA DE ENTRADA');
  console.log(red('  A senha é opcional. Se ativada, será solicitada pelo personalizador.\n'));
  const choice = await ask(red('  Ativar senha? [s/N]: '));

  if (choice.toLowerCase() !== 's') {
    cfg.passwordEnabled = false;
    cfg.password = '';
    return;
  }

  const p1 = await ask(red('  Nova senha: '));
  const p2 = await ask(red('  Confirme a senha: '));
  if (!p1 || p1 !== p2) {
    console.log(red('\n  Senhas não conferem. Nada foi alterado.'));
    await sleep(1200);
    return;
  }

  cfg.passwordEnabled = true;
  cfg.password = p1;
}

async function preview(cfg) {
  header(cfg, 'VISUALIZAÇÃO');
  if (cfg.showClock) console.log(red(`  🕒 ${now()}`));
  if (cfg.showBanner) banner(cfg);
  console.log();
  console.log(red(cfg.welcome));
  console.log();
  console.log(`${red('  ')}${color(cfg.promptColor, `▭❦❲${cfg.name}❳❦▭`)} ${red('$')}`);
  console.log();
  await ask(red('  ENTER para voltar...'));
}

async function saveAndApply(cfg) {
  header(cfg, 'SALVANDO PERSONALIZAÇÃO');
  await loading();
  saveConfig(cfg);
  applyBashrc(cfg);
  console.log(red('  ✓ Configuração salva em: ~/.termux-personalizer.json'));
  console.log(red('  ✓ Prompt aplicado em: ~/.bashrc'));
  console.log(red('  ✓ Feche e abra o Termux para ver tudo automaticamente.'));
  await ask(red('\n  ENTER para continuar...'));
}

function passwordGate(cfg) {
  return new Promise(resolve => {
    if (!cfg.passwordEnabled) return resolve(true);
    process.stdout.write('\x1b[2J\x1b[H');
    console.log(red('╔══════════════════════════════════════════════════════════════╗'));
    console.log(red('║                 ACESSO PROTEGIDO                            ║'));
    console.log(red('╚══════════════════════════════════════════════════════════════╝\n'));
    rl.question(red('  Senha: '), answer => {
      resolve(answer === cfg.password);
    });
  });
}

async function mainMenu(cfg) {
  while (true) {
    header(cfg);
    if (cfg.showClock) console.log(red(`  🕒 ${now()}`));
    console.log();
    if (cfg.showBanner) banner(cfg);

    console.log(red('\n  ┌──────────────────────────────────────────────────────────┐'));
    console.log(red('  │  1. ✦ Alterar nome                                      │'));
    console.log(red('  │  2. ✦ Escolher arte (16 estilos)                       │'));
    console.log(red('  │  3. ✦ Escolher cor do banner                           │'));
    console.log(red('  │  4. ✦ Escolher cor do prompt                            │'));
    console.log(red('  │  5. ✦ Mensagem de boas-vindas                          │'));
    console.log(red('  │  6. ✦ Ativar/desativar senha                           │'));
    console.log(red('  │  7. ✦ Visualizar resultado                              │'));
    console.log(red('  │  8. ✦ Aplicar e salvar                                  │'));
    console.log(red('  │  9. ✦ Sair                                               │'));
    console.log(red('  └──────────────────────────────────────────────────────────┘'));
    console.log(red(`\n  Criador: Doctor valeyard C'rizz Lunático`));

    const op = await ask(red('\n  Selecione uma opção: '));

    switch (op) {
      case '1': await setName(cfg); break;
      case '2': await chooseStyle(cfg); break;
      case '3': await chooseColor(cfg); break;
      case '4': await chooseColor(cfg, true); break;
      case '5': await setWelcome(cfg); break;
      case '6': await setPassword(cfg); break;
      case '7': await preview(cfg); break;
      case '8': await saveAndApply(cfg); break;
      case '9':
        console.log(red('\n  Saindo... Até a próxima.'));
        rl.close();
        return;
      default:
        console.log(red('\n  Opção inválida.'));
        await sleep(700);
    }
  }
}

(async () => {
  const cfg = loadConfig();

  if (!(await passwordGate(cfg))) {
    console.log(red('\n  Acesso negado.'));
    rl.close();
    process.exit(1);
  }

  await mainMenu(cfg);
})();
